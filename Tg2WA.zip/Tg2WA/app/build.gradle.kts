plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.tg2wa"
    compileSdk = 34
    defaultConfig { applicationId = "com.tg2wa"; minSdk = 24; targetSdk = 34; versionCode = 1; versionName = "1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    packaging { jniLibs { useLegacyPackaging = true } }
}
dependencies {
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("dev.ffmpegkit-maintained:ffmpeg-kit-full:6.0.3")
    implementation("com.arthenica:smart-exception-java:0.2.1")
}
