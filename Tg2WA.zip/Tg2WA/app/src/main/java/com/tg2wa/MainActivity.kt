package com.tg2wa

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var list: LinearLayout
    private lateinit var go: Button

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("p", MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        val token = EditText(this).apply {
            hint = "توكن البوت (من BotFather)"; setText(prefs.getString("t", ""))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val link = EditText(this).apply { hint = "رابط الحزمة: t.me/addstickers/..."; setSingleLine() }
        go = Button(this).apply { text = "تحويل" }
        status = TextView(this).apply { setPadding(0, pad, 0, pad) }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listOf(token, link, go, status, list).forEach { root.addView(it, MATCH_PARENT, -2) }
        setContentView(ScrollView(this).apply { addView(root) })

        go.setOnClickListener {
            val t = token.text.toString().trim(); val l = link.text.toString().trim()
            if (t.isEmpty() || l.isEmpty()) { status.text = "عبّي التوكن والرابط"; return@setOnClickListener }
            prefs.edit().putString("t", t).apply()
            go.isEnabled = false; list.removeAllViews()
            Thread { work(t, l) }.start()
        }
    }

    private fun say(s: String) = runOnUiThread { status.text = s }

    private fun work(token: String, link: String) {
        try {
            val name = link.substringAfterLast("/").substringBefore("?")
            require(name.matches(Regex("[A-Za-z0-9_]{1,64}"))) { "رابط غير صحيح" }
            say("جاري جلب الحزمة…")
            val api = TelegramApi(token)
            val (title, all) = api.stickerSet(name)
            val vids = all.filter { it.isVideo }
            require(vids.size >= 3) { "الحزمة فيها أقل من 3 ملصقات متحركة (WEBM)" }
            val raw = File(cacheDir, "raw").apply { mkdirs() }
            val chunks = vids.chunked(30).filter { it.size >= 3 }
            chunks.forEachIndexed { idx, chunk ->
                val id = "${name.lowercase()}_${idx + 1}"
                val dir = File(filesDir, "packs/$id").apply { mkdirs() }
                val files = JSONArray()
                chunk.forEachIndexed { i, s ->
                    say("حزمة ${idx + 1}/${chunks.size} – ملصق ${i + 1}/${chunk.size}")
                    val src = File(raw, "${s.fileId.hashCode()}.webm")
                    if (!src.exists() || src.length() == 0L) api.download(s.fileId, src)
                    val out = File(dir, "${i + 1}.webp")
                    if ((out.exists() && out.length() > 0) || Converter.toWebp(src, out)) {
                        if (i == 0 || !File(dir, "tray.png").exists()) Converter.tray(src, File(dir, "tray.png"))
                        files.put(JSONObject().put("f", out.name).put("e", s.emoji.ifEmpty { "😀" }))
                    }
                }
                if (files.length() < 3 || !File(dir, "tray.png").exists()) { dir.deleteRecursively(); return@forEachIndexed }
                val label = if (chunks.size > 1) "$title ${idx + 1}" else title
                File(dir, "meta.json").writeText(JSONObject().put("name", label.take(128))
                    .put("version", System.currentTimeMillis().toString()).put("files", files).toString())
                runOnUiThread { addButton(id, label) }
            }
            say("تم ✅ اضغط على الحزمة لإضافتها لواتساب")
        } catch (e: Exception) {
            say("خطأ: " + (e.message ?: e.javaClass.simpleName).replace(token, "***"))
        } finally { runOnUiThread { go.isEnabled = true } }
    }

    private fun addButton(id: String, label: String) {
        list.addView(Button(this).apply {
            text = "إضافة إلى واتساب: $label"
            setOnClickListener {
                val i = Intent("com.whatsapp.intent.action.ENABLE_STICKER_PACK")
                    .putExtra("sticker_pack_id", id)
                    .putExtra("sticker_pack_authority", "$packageName.stickercontentprovider")
                    .putExtra("sticker_pack_name", label)
                try { startActivityForResult(i, 200) }
                catch (e: ActivityNotFoundException) { Toast.makeText(context, "واتساب غير مثبت", Toast.LENGTH_SHORT).show() }
            }
        })
    }
}
