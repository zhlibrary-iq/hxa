package com.tg2wa

import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import java.io.File

/** WEBM (VP9+alpha) → WebP متحرك 512×512 بحجم أقل من 500KB (شرط واتساب). */
object Converter {
    private const val MAX_BYTES = 500_000L
    // (fps, quality) تنازلياً حتى يدخل الحجم
    private val STEPS = listOf(15 to 60, 15 to 40, 12 to 30, 10 to 20, 8 to 10)

    private fun pad(size: Int) =
        "scale=$size:$size:force_original_aspect_ratio=decrease," +
        "pad=$size:$size:(ow-iw)/2:(oh-ih)/2:color=0x00000000,format=rgba"

    fun toWebp(src: File, dst: File): Boolean {
        for ((fps, q) in STEPS) {
            dst.delete()
            val s = FFmpegKit.executeWithArguments(arrayOf(
                "-y", "-c:v", "libvpx-vp9", "-i", src.path, "-t", "8",
                "-vf", "fps=$fps,${pad(512)}",
                "-c:v", "libwebp", "-lossless", "0", "-q:v", "$q",
                "-compression_level", "6", "-loop", "0", "-an", "-vsync", "0", dst.path))
            if (ReturnCode.isSuccess(s.returnCode) && dst.length() in 1..MAX_BYTES) return true
        }
        dst.delete(); return false
    }

    fun tray(src: File, dst: File): Boolean {
        val s = FFmpegKit.executeWithArguments(arrayOf(
            "-y", "-c:v", "libvpx-vp9", "-i", src.path, "-frames:v", "1",
            "-vf", pad(96), dst.path))
        return ReturnCode.isSuccess(s.returnCode) && dst.exists()
    }
}
