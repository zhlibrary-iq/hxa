package com.tg2wa

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File

data class TgSticker(val fileId: String, val emoji: String, val isVideo: Boolean)

/** طلبان فقط لكل حزمة: getStickerSet مرة، ولكل ملف getFile + تنزيل (ويُتخطى إن كان محفوظاً). */
class TelegramApi(private val token: String) {
    private val http = OkHttpClient()
    private val base get() = "https://api.telegram.org"

    private fun call(url: String): okhttp3.Response {
        val r = http.newCall(Request.Builder().url(url).build()).execute()
        if (!r.isSuccessful) { r.close(); error("فشل الطلب (${r.code}) – تأكد من التوكن والرابط") }
        return r
    }

    fun stickerSet(name: String): Pair<String, List<TgSticker>> {
        val j = JSONObject(call("$base/bot$token/getStickerSet?name=$name").use { it.body!!.string() })
        val res = j.getJSONObject("result")
        val arr = res.getJSONArray("stickers")
        val list = (0 until arr.length()).map {
            val s = arr.getJSONObject(it)
            TgSticker(s.getString("file_id"), s.optString("emoji", "😀"), s.optBoolean("is_video"))
        }
        return res.optString("title", name) to list
    }

    fun download(fileId: String, dest: File) {
        val path = JSONObject(call("$base/bot$token/getFile?file_id=$fileId").use { it.body!!.string() })
            .getJSONObject("result").getString("file_path")
        call("$base/file/bot$token/$path").use { r ->
            dest.outputStream().use { out -> r.body!!.byteStream().copyTo(out) }
        }
    }
}
