package com.tg2wa

import android.content.ContentProvider
import android.content.ContentValues
import android.content.res.AssetFileDescriptor
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import org.json.JSONObject
import java.io.File

/** ContentProvider بالشكل الذي يطلبه واتساب لحزم الملصقات. بيانات كل حزمة في filesDir/packs/<id>/ */
class StickerProvider : ContentProvider() {
    private val root get() = File(context!!.filesDir, "packs")
    private fun packs() = root.listFiles { f -> f.isDirectory }?.sortedBy { it.name } ?: emptyList()
    private fun meta(d: File) = JSONObject(File(d, "meta.json").readText())

    override fun onCreate() = true

    override fun query(uri: Uri, p: Array<String>?, s: String?, a: Array<String>?, o: String?): Cursor? {
        val seg = uri.pathSegments
        return when (seg.firstOrNull()) {
            "metadata" -> {
                val id = seg.getOrNull(1)
                val c = MatrixCursor(arrayOf(
                    "sticker_pack_identifier", "sticker_pack_name", "sticker_pack_publisher", "sticker_pack_icon",
                    "android_play_store_link", "ios_app_download_link", "sticker_pack_publisher_email",
                    "sticker_pack_publisher_website", "sticker_pack_privacy_policy_website",
                    "sticker_pack_license_agreement_website", "image_data_version",
                    "whatsapp_will_not_cache_stickers", "animated_sticker_pack"))
                packs().filter { id == null || it.name == id }.forEach { d ->
                    val m = meta(d)
                    c.addRow(arrayOf(d.name, m.getString("name"), "Tg2WA", "tray.png", "", "", "", "", "", "",
                        m.getString("version"), 0, 1))
                }
                c
            }
            "stickers" -> {
                val d = packs().firstOrNull { it.name == seg.getOrNull(1) } ?: return null
                val c = MatrixCursor(arrayOf("sticker_file_name", "sticker_emoji", "sticker_accessibility_text"))
                val arr = meta(d).getJSONArray("files")
                for (i in 0 until arr.length()) {
                    val f = arr.getJSONObject(i)
                    c.addRow(arrayOf(f.getString("f"), f.getString("e"), "sticker"))
                }
                c
            }
            else -> null
        }
    }

    override fun openAssetFile(uri: Uri, mode: String): AssetFileDescriptor? {
        val seg = uri.pathSegments
        if (seg.size != 3 || seg[0] != "stickers_asset") return null
        val d = packs().firstOrNull { it.name == seg[1] } ?: return null
        val f = File(d, seg[2])
        if (!seg[2].matches(Regex("[\\w]+\\.(webp|png)")) || !f.isFile) return null
        return AssetFileDescriptor(ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY), 0, -1)
    }

    override fun getType(uri: Uri): String? = when (uri.pathSegments.firstOrNull()) {
        "metadata" -> "vnd.android.cursor.dir/vnd.${context!!.packageName}.stickercontentprovider.metadata"
        "stickers" -> "vnd.android.cursor.dir/vnd.${context!!.packageName}.stickercontentprovider.stickers"
        "stickers_asset" -> if (uri.lastPathSegment!!.endsWith(".png")) "image/png" else "image/webp"
        else -> null
    }

    override fun insert(u: Uri, v: ContentValues?): Uri? = null
    override fun update(u: Uri, v: ContentValues?, s: String?, a: Array<String>?) = 0
    override fun delete(u: Uri, s: String?, a: Array<String>?) = 0
}
